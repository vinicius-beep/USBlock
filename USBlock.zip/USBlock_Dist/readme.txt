USBlock - Bloqueador de Portas USB
Este é o executável do USBlock, uma ferramenta simples para gerenciar o acesso às portas USB no Windows.

Como usar:

Descompacte todo o conteúdo deste arquivo ZIP em uma nova pasta.

Execute "usblock.exe".

Para que a interface gráfica funcione corretamente, o arquivo "estilo.css" deve estar na mesma pasta do executável.

Requisitos:

Windows 10/11 (testado no MSYS2 MinGW x64).

Para um funcionamento ideal do GTK4, certifique-se de que todas as bibliotecas GTK4 necessárias estejam disponíveis no seu sistema (geralmente instaladas junto com ferramentas de desenvolvimento como o MSYS2).

Funcionalidades:

Lista dispositivos USB conectados.

Botão para Bloquear/Desbloquear o acesso USB (requer privilégios de administrador para bloquear/desbloquear).

Botão "Scannear" para listar arquivos em dispositivos USB desbloqueados.

Observação:
O bloqueio/desbloqueio USB pode exigir permissões de administrador. Execute o aplicativo como administrador se encontrar problemas.